# ownCard
An angularjs application to create your own card by writing your name and generating by the application then you can download the image.
